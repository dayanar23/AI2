El código presente genera un archivo .csv para ser introducido en la herramienta Weka.


La versión de python utilizada en el código es 2.7 

Para instalar dependencias:

	pip install requests bs4

Para ejecutar:

	python commoncrawler.py -d urls.txt