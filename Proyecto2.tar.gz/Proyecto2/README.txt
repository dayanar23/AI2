Para correr las soluciones basta con ejecutar

	python main.py

y seguir las instrucciones del programa principal.
